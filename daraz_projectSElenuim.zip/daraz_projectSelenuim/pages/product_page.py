from selenium.webdriver.common.by import By as SeleniumBy
from pages.base_page import BasePage

class ProductPage(BasePage):
    FREE_SHIPPING = (SeleniumBy.XPATH, "//span[contains(text(), 'Free Shipping')]")

    def has_free_shipping(self):
        try:
            return self.is_visible(self.FREE_SHIPPING)
        except:
            return False
