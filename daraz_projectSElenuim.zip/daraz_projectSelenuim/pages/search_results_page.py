from selenium.webdriver.common.by import By as SeleniumBy
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from pages.base_page import BasePage
import time

class SearchResultsPage(BasePage):
    SEE_MORE_BRAND = (SeleniumBy.XPATH, "//span[contains(text(), 'VIEW MORE')]")
    MIN_PRICE = (SeleniumBy.NAME, 'price-start')
    MAX_PRICE = (SeleniumBy.NAME, 'price-end')
    APPLY_PRICE = (SeleniumBy.XPATH, "//button[.='Apply']")
    PRODUCTS = (SeleniumBy.CSS_SELECTOR, ".c2prKC")

    def apply_brand_filter(self, brand_name):
        try:
            see_more = self.driver.find_element(*self.SEE_MORE_BRAND)
            self.driver.execute_script("arguments[0].scrollIntoView(true);", see_more)
            time.sleep(1)
            see_more.click()
            time.sleep(2)
        except:
            print("VIEW MORE not found or already expanded.")

        xpath_variants = [
            f"//label[contains(text(), '{brand_name}')]",
            f"//label[contains(translate(., 'abcdefghijklmnopqrstuvwxyz', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'), '{brand_name.upper()}')]",
            f"//label[contains(., '{brand_name.lower()}')]",
            f"//label[contains(., '{brand_name.capitalize()}')]"
        ]

        brand_found = False
        for _ in range(10):
            for xpath in xpath_variants:
                try:
                    brand = self.driver.find_element(SeleniumBy.XPATH, xpath)
                    self.driver.execute_script("arguments[0].scrollIntoView(true);", brand)
                    ActionChains(self.driver).move_to_element(brand).perform()
                    self.wait.until(EC.element_to_be_clickable((SeleniumBy.XPATH, xpath))).click()
                    brand_found = True
                    break
                except:
                    continue
            if brand_found:
                break
            self.driver.execute_script("window.scrollBy(0, 300);")
            time.sleep(1.5)

        if not brand_found:
            raise Exception(f"Brand '{brand_name}' not found after scrolling.")

    def apply_price_filter(self, min_price, max_price):
        self.driver.find_element(*self.MIN_PRICE).clear()
        self.driver.find_element(*self.MIN_PRICE).send_keys(min_price)
        self.driver.find_element(*self.MAX_PRICE).clear()
        self.driver.find_element(*self.MAX_PRICE).send_keys(max_price)
        self.driver.find_element(*self.APPLY_PRICE).click()
        time.sleep(3)

    def count_products(self):
        products = self.driver.find_elements(*self.PRODUCTS)
        return len(products)

    def click_any_product(self):
        products = self.driver.find_elements(*self.PRODUCTS)
        if products:
            products[0].click()
        else:
            raise Exception("No products to click.")

    def apply_location_filter(self, location="Pakistan"):
        try:
            location_xpath = f"//label[contains(., '{location}')]"
            checkbox = self.driver.find_element(SeleniumBy.XPATH, location_xpath)
            self.driver.execute_script("arguments[0].scrollIntoView(true);", checkbox)
            self.wait.until(EC.element_to_be_clickable((SeleniumBy.XPATH, location_xpath))).click()
            time.sleep(2)
        except Exception as e:
            print(f"Could not apply 'Ships from {location}' filter: {e}")

    def apply_rating_filter(self, rating_text="4 Stars & Up"):
        try:
            xpath = f"//label[contains(., '{rating_text}')]"
            checkbox = self.driver.find_element(SeleniumBy.XPATH, xpath)
            self.driver.execute_script("arguments[0].scrollIntoView(true);", checkbox)
            self.wait.until(EC.element_to_be_clickable((SeleniumBy.XPATH, xpath))).click()
            time.sleep(2)
        except Exception as e:
            print(f"Could not apply rating filter: {e}")

    def apply_warranty_filter(self):
        try:
            xpath = "//label[contains(., 'Warranty')]"
            checkbox = self.driver.find_element(SeleniumBy.XPATH, xpath)
            self.driver.execute_script("arguments[0].scrollIntoView(true);", checkbox)
            self.wait.until(EC.element_to_be_clickable((SeleniumBy.XPATH, xpath))).click()
            time.sleep(2)
        except Exception as e:
            print(f"Could not apply warranty filter: {e}")
