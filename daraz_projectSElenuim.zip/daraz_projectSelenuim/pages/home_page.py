from selenium.webdriver.common.by import By as SeleniumBy
from selenium.webdriver.support import expected_conditions as EC
from pages.base_page import BasePage

class HomePage(BasePage):
    SEARCH_BAR = (SeleniumBy.NAME, "q")

    def search_item(self, item):
        try:
            search_input = self.wait.until(EC.element_to_be_clickable(self.SEARCH_BAR))
            search_input.clear()
            search_input.send_keys(item + "\n")
        except Exception as e:
            print(f" Error during search input: {e}")
            raise
