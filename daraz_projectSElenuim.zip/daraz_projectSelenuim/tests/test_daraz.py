from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from pages.search_results_page import SearchResultsPage
from pages.product_page import ProductPage
import time

def test_search_and_filter():
    
    chrome_options = Options()
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option("useAutomationExtension", False)
    driver = webdriver.Chrome(options=chrome_options)
    driver.get("https://www.daraz.pk/catalog/?spm=a2a0e.tm80335142.search.d_go&q=electronics")
    driver.maximize_window()

    try:
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".c2prKC"))
        )
        results = SearchResultsPage(driver)
        results.apply_price_filter("500", "5000")
        time.sleep(2)
        count = results.count_products()
        print(f"Products found: {count}")
        assert count > 0, " No products found after applying price filter."
        results.click_any_product()
        time.sleep(3)
        product = ProductPage(driver)
        assert product.has_free_shipping(), " Free shipping not available."

    finally:
        driver.quit()
